DATABASES = {
'default': {
'ENGINE': 'django.db.backends.postgresql',
'NAME': 'timetracker_db',
'USER': 'postgres',
'PASSWORD': 'P0stgresadmin23!',
'HOST': 'localhost',
'PORT': '5432',
}
}

---

time_tracker secrets:
db name: timetracker_db

django db:
super user: saiful / admin (changed to use email address)
trionxai@gmail.com
pw: T!metrackerdb23!

---

db root directory: C:\Program Files\PostgreSQL\16\data
postgre database user user:
user: postgres
pw: P0stgresadmin23!
port: 5432

---

Installation Directory: C:\Program Files\PostgreSQL\16
Server Installation Directory: C:\Program Files\PostgreSQL\16
Data Directory: C:\Program Files\PostgreSQL\16\data
Database Port: 5432
Database Superuser: postgres
Operating System Account: NT AUTHORITY\NetworkService
Database Service: postgresql-x64-16
Command Line Tools Installation Directory: C:\Program Files\PostgreSQL\16
pgAdmin4 Installation Directory: C:\Program Files\PostgreSQL\16\pgAdmin 4
Stack Builder Installation Directory: C:\Program Files\PostgreSQL\16
Installation Log: C:\Users\saiful\AppData\Local\Temp\install-postgresql.log
