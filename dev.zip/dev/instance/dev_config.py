# dev_config.py
DEBUG = True
OPENAI_API_KEY = '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'

# dev_config.py
#SQLALCHEMY_DATABASE_URI = 'sqlite:///timesheet.db'
SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:TimeSheet@2023@localhost:5432/timesheet_db'
SECRET_KEY = 'your_secret_key_here'

