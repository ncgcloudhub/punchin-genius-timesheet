-- Begin transaction
BEGIN;

-- Create a new version tracking table
CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Insert the current version
INSERT INTO alembic_version VALUES('e253e4ff5de8');

-- 'user' is a reserved keyword in PostgreSQL, so it is enclosed in double quotes.
CREATE TABLE "user" (
    id SERIAL PRIMARY KEY,
    username VARCHAR(80) NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_admin BOOLEAN,
    email VARCHAR(120) NOT NULL,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    role VARCHAR(20),
    UNIQUE (email),
    UNIQUE (username)
);

-- Insert users into the "user" table.
INSERT INTO "user" (username, password, is_admin, email, first_name, last_name, role) VALUES
('saiful', 'scrypt:32768:8:1$GK6ZPfjrAdcB7Th4$772977cf2a92f4cb6425d90aa6ec7d93c8dc462bbff4981d0ee70a81f7e08622270133f1773db2cbd40030368681688b728f54573aeaaf4649620d4720195965', false, 'saif.taxpro@outlook.com', 'Saiful', 'Bhuiyan', 'Employee'),
('saifuladmin', 'scrypt:32768:8:1$TrfbDUoIQh80cshc$01331aaed76cfe6b6a4c0eb5f1e3606d77ba5eb3498f635588bb1278e14624638968413ec49f89acbe6fc781a2e8ddba20bdb8834485b6151c29d0b0f18d8c54', true, 'saif.bhuiyan@gmail.com', 'Saiful', 'Admin', 'Admin');

-- Create a table to track time entries.
CREATE TABLE time_entry (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    date DATE NOT NULL,
    sign_in_time TIME NOT NULL,
    sign_out_time TIME,
    delete_reason VARCHAR,
    FOREIGN KEY(user_id) REFERENCES "user" (id)
);

-- Insert time entries into the time_entry table.
INSERT INTO time_entry (user_id, date, sign_in_time, sign_out_time, delete_reason) VALUES
(2, '2023-09-15', '13:14:00', '19:34:13', NULL),
(2, '2023-09-15', '07:34:00', '21:00:00', NULL),
(1, '2023-09-15', '07:48:00', '19:49:05', NULL),
(1, '2023-09-15', '07:51:00', NULL, NULL),
(2, '2023-09-14', '22:03:00', '23:03:00', NULL),
(2, '2023-09-05', '18:03:00', '22:02:00', NULL),
(2, '2023-08-30', '14:04:00', '23:04:00', NULL),
(2, '2023-08-31', '22:17:00', '23:18:00', NULL),
(2, '2023-09-16', '01:15:00', '02:16:00', NULL),
(2, '2023-09-16', '09:00:00', '17:45:00', NULL),
(2, '2023-09-17', '09:00:00', '18:00:00', NULL),
(2, '2023-09-17', '01:29:00', '02:30:00', NULL),
(2, '2023-09-17', '22:30:00', '17:45:00', NULL),
(2, '2023-09-16', '08:28:00', '08:34:00', NULL),
(2, '2023-09-18', '06:29:00', '07:29:00', NULL),
(2, '2023-09-17', '09:00:00', '19:18:00', NULL),
(2, '2023-09-17', '10:15:00', NULL, NULL);
Commit