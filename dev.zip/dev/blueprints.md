your_project/
|-- your_app/
|---- profile/
|------ __init__.py
|------ routes.py
|---- settings/
|------ __init__.py
|------ routes.py
|---- templates/
|------ profile/
|-------- profile.html
|------ settings/
|-------- settings.html
