BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "user" (
	"id"	INTEGER NOT NULL,
	"username"	VARCHAR(80) NOT NULL,
	"password"	VARCHAR(120) NOT NULL,
	"is_admin"	BOOLEAN,
	PRIMARY KEY("id"),
	UNIQUE("username")
);
CREATE TABLE IF NOT EXISTS "time_entry" (
	"id"	INTEGER NOT NULL,
	"user_id"	INTEGER NOT NULL,
	"date"	DATE NOT NULL,
	"sign_in_time"	TIME NOT NULL,
	"sign_out_time"	TIME,
	"delete_reason"	VARCHAR,
	PRIMARY KEY("id"),
	FOREIGN KEY("user_id") REFERENCES "user"("id")
);
CREATE TABLE IF NOT EXISTS "alembic_version" (
	"version_num"	VARCHAR(32) NOT NULL,
	CONSTRAINT "alembic_version_pkc" PRIMARY KEY("version_num")
);
CREATE TABLE IF NOT EXISTS "_alembic_tmp_user" (
	"id"	INTEGER NOT NULL,
	"username"	VARCHAR(80) NOT NULL,
	"password"	VARCHAR(120) NOT NULL,
	"is_admin"	BOOLEAN,
	"email"	VARCHAR(120) NOT NULL,
	PRIMARY KEY("id"),
	UNIQUE("username"),
	CONSTRAINT "uq_user_email" UNIQUE("email")
);
INSERT INTO "user" VALUES (1,'saiful','scrypt:32768:8:1$h6ZJ6mCEBcrSFw1v$b3d335f59a839e6a6c8b433803f51a4ae60baceb2fe6de77d75a2abf221a4c98d122787b81cb63789d0344548add515c072761b4114c0d01d4d861ac988a2c26',NULL);
INSERT INTO "time_entry" VALUES (1,1,'2023-09-10','11:33:00.000000','15:33:00.000000',NULL);
INSERT INTO "time_entry" VALUES (2,1,'2023-09-10','21:36:00.000000','23:36:00.000000',NULL);
INSERT INTO "time_entry" VALUES (3,1,'2023-09-11','11:44:00.000000','13:44:00.000000',NULL);
INSERT INTO "time_entry" VALUES (4,1,'2023-09-11','18:44:00.000000','23:42:00.000000',NULL);
INSERT INTO "alembic_version" VALUES ('0eb117b29d5a');
COMMIT;
